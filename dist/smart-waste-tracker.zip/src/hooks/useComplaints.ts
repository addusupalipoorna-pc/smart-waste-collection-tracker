import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Complaint, ComplaintStatus } from '@/types';

type ComplaintQuery = 'own' | 'assigned' | 'all';

interface UseComplaintsOptions {
  query: ComplaintQuery;
  userId: string;
  status?: ComplaintStatus;
  search?: string;
  limit?: number;
}

export function useComplaints({ query, userId, status, search, limit }: UseComplaintsOptions) {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchComplaints = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let dbQuery = supabase.from('complaints').select(`
        *,
        citizen:profiles!complaints_citizen_id_fkey(id, full_name, role, zone),
        assigned_collector:profiles!complaints_assigned_collector_id_fkey(id, full_name, role, zone)
      `);

      if (query === 'own') {
        dbQuery = dbQuery.eq('citizen_id', userId);
      } else if (query === 'assigned') {
        dbQuery = dbQuery.eq('assigned_collector_id', userId);
      }

      if (status) {
        dbQuery = dbQuery.eq('status', status);
      }

      if (search) {
        dbQuery = dbQuery.or(`description.ilike.%${search}%,complaint_code.ilike.%${search}%,address.ilike.%${search}%`);
      }

      dbQuery = dbQuery.order('created_at', { ascending: false });
      if (limit) dbQuery = dbQuery.limit(limit);

      const { data, error: err } = await dbQuery;
      if (err) throw err;
      setComplaints((data as Complaint[]) || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load complaints');
    } finally {
      setLoading(false);
    }
  }, [query, userId, status, search, limit]);

  useEffect(() => {
    fetchComplaints();
  }, [fetchComplaints]);

  return { complaints, loading, error, refetch: fetchComplaints };
}
