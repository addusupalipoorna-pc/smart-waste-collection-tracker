import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ClipboardList, Clock, PlayCircle, CheckCircle2, Navigation, Truck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { StatCard, EmptyState, LoadingSpinner } from '@/components/ui';
import { ComplaintCard } from '@/components/ComplaintCard';
import { getComplaintStats } from '@/lib/utils';

export function CollectorDashboard() {
  const { profile } = useAuth();
  const { complaints, loading } = useComplaints({
    query: 'assigned',
    userId: profile!.id,
    limit: 6,
  });

  const stats = getComplaintStats(complaints);
  const activeTasks = complaints.filter((c) => c.status === 'Assigned' || c.status === 'In Progress');

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={`Welcome, ${profile!.full_name.split(' ')[0]}`}
        subtitle="Your assigned waste collection tasks"
        action={
          <Link to="/collector/assigned" className="btn-secondary">
            <ClipboardList className="h-4 w-4" /> All Tasks
          </Link>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Total Assigned" value={stats.total} icon={<ClipboardList className="h-5 w-5" />} color="#2563eb" />
        <StatCard label="New Tasks" value={stats.assigned} icon={<Clock className="h-5 w-5" />} color="#ca8a04" />
        <StatCard label="In Progress" value={stats.inProgress} icon={<PlayCircle className="h-5 w-5" />} color="#0891b2" />
        <StatCard label="Completed" value={stats.completed} icon={<CheckCircle2 className="h-5 w-5" />} color="#16a34a" />
      </div>

      {activeTasks.length > 0 && (
        <div className="card p-4 mb-6 bg-primary-50/50 border-primary-100">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-100 text-primary-600">
              <Truck className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-slate-900 text-sm">
                You have {activeTasks.length} active {activeTasks.length === 1 ? 'task' : 'tasks'}
              </p>
              <p className="text-xs text-slate-500">Tap a task below to view details, navigate, and update status.</p>
            </div>
            <Link to="/collector/map" className="btn-primary text-sm">
              <Navigation className="h-4 w-4" /> Route Map
            </Link>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-slate-900">Recent Tasks</h3>
        {complaints.length > 0 && (
          <Link to="/collector/assigned" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
            View all
          </Link>
        )}
      </div>

      {complaints.length === 0 ? (
        <EmptyState
          icon={<ClipboardList className="h-7 w-7" />}
          title="No tasks assigned yet"
          message="When an admin assigns you a waste complaint, it will appear here. Check back soon."
        />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {complaints.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <ComplaintCard complaint={c} to={`/complaints/${c.id}`} showCitizen />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
