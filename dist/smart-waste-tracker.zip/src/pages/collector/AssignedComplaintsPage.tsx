import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, ClipboardList } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { ComplaintCard } from '@/components/ComplaintCard';
import { EmptyState, LoadingSpinner } from '@/components/ui';
import type { ComplaintStatus } from '@/types';
import { STATUS_META } from '@/lib/constants';

const statusFilters: (ComplaintStatus | 'all')[] = ['all', 'Assigned', 'In Progress', 'Completed'];

export function AssignedComplaintsPage() {
  const { profile } = useAuth();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | 'all'>('all');

  const { complaints, loading } = useComplaints({
    query: 'assigned',
    userId: profile!.id,
    search: search || undefined,
    status: statusFilter === 'all' ? undefined : statusFilter,
  });

  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { all: complaints.length };
    for (const s of statusFilters) {
      if (s !== 'all') counts[s] = complaints.filter((c) => c.status === s).length;
    }
    return counts;
  }, [complaints]);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader title="Assigned Tasks" subtitle="All waste complaints assigned to you" />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <input
          className="input pl-10"
          placeholder="Search by complaint ID, description, or location..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="flex items-center gap-2 mb-6 overflow-x-auto scrollbar-hide pb-1">
        <Filter className="h-4 w-4 text-slate-400 shrink-0" />
        {statusFilters.map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              statusFilter === s
                ? 'bg-primary-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {s === 'all' ? 'All' : STATUS_META[s as ComplaintStatus].label}
            <span className={`ml-1.5 text-xs ${statusFilter === s ? 'text-primary-100' : 'text-slate-400'}`}>
              {statusCounts[s] || 0}
            </span>
          </button>
        ))}
      </div>

      {complaints.length === 0 ? (
        <EmptyState
          icon={<ClipboardList className="h-7 w-7" />}
          title={search || statusFilter !== 'all' ? 'No matching tasks' : 'No tasks assigned yet'}
          message={
            search || statusFilter !== 'all'
              ? 'Try adjusting your search or filter.'
              : 'When an admin assigns you a complaint, it will show up here.'
          }
        />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {complaints.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <ComplaintCard complaint={c} to={`/complaints/${c.id}`} showCitizen />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
