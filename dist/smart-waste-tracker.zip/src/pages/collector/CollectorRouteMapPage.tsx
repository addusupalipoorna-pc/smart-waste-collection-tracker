import { useNavigate } from 'react-router-dom';
import { Navigation, MapPin } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { MapView } from '@/components/MapView';
import { EmptyState, LoadingSpinner } from '@/components/ui';
import { STATUS_META } from '@/lib/constants';

export function CollectorRouteMapPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const { complaints, loading } = useComplaints({
    query: 'assigned',
    userId: profile!.id,
  });

  const geoComplaints = complaints.filter((c) => c.latitude != null && c.longitude != null);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Route Map"
        subtitle="All your assigned tasks plotted on the map"
      />

      {geoComplaints.length === 0 ? (
        <EmptyState
          icon={<MapPin className="h-7 w-7" />}
          title="No mappable tasks"
          message="None of your assigned tasks have GPS coordinates. The map will populate once tasks with locations are assigned to you."
        />
      ) : (
        <div className="space-y-4">
          <MapView
            complaints={geoComplaints}
            height="500px"
            zoom={14}
            onMarkerClick={(id) => navigate(`/complaints/${id}`)}
          />

          <div className="card p-4">
            <h3 className="font-semibold text-slate-900 mb-3">Task List ({geoComplaints.length})</h3>
            <div className="space-y-2">
              {geoComplaints.map((c) => {
                const meta = STATUS_META[c.status];
                return (
                  <div
                    key={c.id}
                    onClick={() => navigate(`/complaints/${c.id}`)}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-900 text-sm">{c.complaint_code}</p>
                      <p className="text-xs text-slate-500 truncate">{c.address || `${c.latitude}, ${c.longitude}`}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="badge" style={{ color: meta.color, backgroundColor: meta.bg }}>{meta.label}</span>
                      <a
                        href={`https://www.openstreetmap.org/directions?from=&to=${c.latitude}%2C${c.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 rounded-lg text-primary-600 hover:bg-primary-50"
                      >
                        <Navigation className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
