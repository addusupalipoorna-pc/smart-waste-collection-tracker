import { useState, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Loader2, AlertCircle, CheckCircle2, Crosshair, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { PhotoUpload } from '@/components/PhotoUpload';
import { MapView } from '@/components/MapView';
import { PageHeader } from '@/components/DashboardLayout';
import { WASTE_TYPES, URGENCY_LEVELS } from '@/lib/constants';
import { supabase } from '@/lib/supabase';
import { sendNotification } from '@/lib/notifications';
import type { WasteType, Urgency } from '@/types';

interface LocationData {
  latitude: number;
  longitude: number;
  address: string;
}

export function ReportWastePage() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [wasteType, setWasteType] = useState<WasteType | ''>('');
  const [description, setDescription] = useState('');
  const [urgency, setUrgency] = useState<Urgency>('Medium');
  const [photos, setPhotos] = useState<string[]>([]);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const captureLocation = useCallback(() => {
    setLocating(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser.');
      setLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        let address = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=16`,
            { headers: { 'Accept-Language': 'en' } }
          );
          if (res.ok) {
            const data = await res.json();
            if (data.display_name) {
              address = data.display_name.split(',').slice(0, 3).join(', ');
            }
          }
        } catch {
          // Keep coordinate-based fallback
        }
        setLocation({ latitude, longitude, address });
        setLocating(false);
      },
      (err) => {
        setLocationError(
          err.code === 1
            ? 'Location permission denied. Please allow location access to tag your complaint.'
            : 'Could not capture location. Please try again.'
        );
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!wasteType) {
      setError('Please select a waste type.');
      return;
    }
    if (description.trim().length < 10) {
      setError('Please provide a description (at least 10 characters).');
      return;
    }
    if (photos.length === 0) {
      setError('Please upload at least one photo of the waste.');
      return;
    }

    setSubmitting(true);
    try {
      const { data, error: insertError } = await supabase
        .from('complaints')
        .insert({
          citizen_id: profile!.id,
          waste_type: wasteType,
          description: description.trim(),
          urgency,
          photos,
          latitude: location?.latitude || null,
          longitude: location?.longitude || null,
          address: location?.address || null,
          status: 'Pending',
        })
        .select()
        .single();

      if (insertError) throw insertError;

      // Notify all admins about the new complaint
      const { data: admins } = await supabase
        .from('profiles')
        .select('id')
        .eq('role', 'admin');

      if (admins) {
        await Promise.all(
          admins.map((a) =>
            sendNotification(
              a.id,
              'New Complaint Filed',
              `A new ${wasteType} waste complaint has been reported in ${location?.address || 'your area'}.`,
              'info',
              data.id
            )
          )
        );
      }

      navigate(`/complaints/${data.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit complaint. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="animate-fade-in max-w-3xl mx-auto">
      <Link to="/citizen" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to Dashboard
      </Link>
      <PageHeader title="Report a Waste Issue" subtitle="Fill in the details below and we'll route it to the right team." />

      {error && (
        <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Waste Type */}
        <div className="card p-5">
          <label className="label">Waste Type</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {WASTE_TYPES.map((wt) => (
              <button
                key={wt.value}
                type="button"
                onClick={() => setWasteType(wt.value)}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all border-2 ${
                  wasteType === wt.value
                    ? 'border-primary-500 bg-primary-50 text-primary-700'
                    : 'border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <span className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: wt.color }} />
                {wt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div className="card p-5">
          <label className="label">Description</label>
          <textarea
            required
            rows={4}
            className="input resize-none"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the waste issue. What kind of waste? How bad is it? How long has it been there?"
          />
        </div>

        {/* Urgency */}
        <div className="card p-5">
          <label className="label">Urgency Level</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {URGENCY_LEVELS.map((u) => (
              <button
                key={u.value}
                type="button"
                onClick={() => setUrgency(u.value)}
                className={`px-3 py-2.5 rounded-xl text-sm font-medium transition-all border-2 ${
                  urgency === u.value
                    ? 'border-2 text-white'
                    : 'border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
                style={urgency === u.value ? { backgroundColor: u.color, borderColor: u.color } : {}}
              >
                {u.label}
              </button>
            ))}
          </div>
        </div>

        {/* Photos */}
        <div className="card p-5">
          <PhotoUpload photos={photos} onChange={setPhotos} label="Waste Photos" />
        </div>

        {/* GPS Location */}
        <div className="card p-5">
          <label className="label">GPS Location</label>
          {location ? (
            <div className="space-y-3">
              <div className="flex items-start gap-2 p-3 rounded-xl bg-primary-50 border border-primary-200">
                <CheckCircle2 className="h-4 w-4 text-primary-600 mt-0.5 shrink-0" />
                <div className="text-sm">
                  <p className="text-primary-700 font-medium">{location.address}</p>
                  <p className="text-xs text-primary-600 mt-0.5">
                    Lat: {location.latitude.toFixed(6)}, Lng: {location.longitude.toFixed(6)}
                  </p>
                </div>
              </div>
              <MapView
                singleMarker={{ lat: location.latitude, lng: location.longitude, label: location.address }}
                height="240px"
                zoom={15}
              />
              <button type="button" onClick={captureLocation} className="btn-ghost text-sm">
                <Crosshair className="h-4 w-4" /> Recapture location
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <button
                type="button"
                onClick={captureLocation}
                disabled={locating}
                className="btn-secondary w-full"
              >
                {locating ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Capturing location...</>
                ) : (
                  <><MapPin className="h-4 w-4" /> Capture My Location</>
                )}
              </button>
              {locationError && (
                <p className="text-xs text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3.5 w-3.5" /> {locationError}
                </p>
              )}
              <p className="text-xs text-slate-400">
                Location is optional but highly recommended — it helps collectors find the waste.
              </p>
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <button type="button" onClick={() => navigate('/citizen')} className="btn-secondary flex-1">
            Cancel
          </button>
          <button type="submit" disabled={submitting} className="btn-primary flex-1">
            {submitting ? (
              <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>Submit Complaint</>
            )}
          </button>
        </div>
      </form>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-100"
      >
        <p className="text-xs text-slate-500">
          Once submitted, your complaint gets a unique ID and a "Pending" status. An admin will review it
          and assign a collector. You'll get a notification at each step.
        </p>
      </motion.div>
    </div>
  );
}
