import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PlusCircle, Clock, CheckCircle2, AlertCircle, Trash2, History } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { StatCard, EmptyState, LoadingSpinner } from '@/components/ui';
import { ComplaintCard } from '@/components/ComplaintCard';
import { getComplaintStats } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

export function CitizenDashboard() {
  const { profile } = useAuth();
  const { complaints, loading, refetch } = useComplaints({
    query: 'own',
    userId: profile!.id,
    limit: 5,
  });

  const stats = getComplaintStats(complaints);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this complaint? This cannot be undone.')) return;
    await supabase.from('complaints').delete().eq('id', id);
    refetch();
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={`Hello, ${profile!.full_name.split(' ')[0]}`}
        subtitle="Here's an overview of your waste complaints"
        action={
          <Link to="/citizen/report" className="btn-primary">
            <PlusCircle className="h-4 w-4" /> Report Waste
          </Link>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Total" value={stats.total} icon={<History className="h-5 w-5" />} color="#16a34a" />
        <StatCard label="Pending" value={stats.pending} icon={<Clock className="h-5 w-5" />} color="#ca8a04" />
        <StatCard label="In Progress" value={stats.assigned + stats.inProgress} icon={<AlertCircle className="h-5 w-5" />} color="#0891b2" />
        <StatCard label="Completed" value={stats.completed} icon={<CheckCircle2 className="h-5 w-5" />} color="#16a34a" />
      </div>

      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-slate-900">Recent Complaints</h3>
        {complaints.length > 0 && (
          <Link to="/citizen/history" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
            View all
          </Link>
        )}
      </div>

      {complaints.length === 0 ? (
        <EmptyState
          icon={<Trash2 className="h-7 w-7" />}
          title="No complaints yet"
          message="When you report a waste issue, it will appear here. Start by reporting your first complaint."
          action={
            <Link to="/citizen/report" className="btn-primary">
              <PlusCircle className="h-4 w-4" /> Report Your First Issue
            </Link>
          }
        />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {complaints.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <ComplaintCard complaint={c} to={`/complaints/${c.id}`} onDelete={handleDelete} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
