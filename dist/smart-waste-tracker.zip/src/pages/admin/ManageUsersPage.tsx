import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Search, ShieldCheck, AlertCircle, User as UserIcon } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { PageHeader } from '@/components/DashboardLayout';
import { LoadingSpinner, EmptyState, ErrorState } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { ROLE_META } from '@/lib/constants';
import { formatDate, initialFromName, classNames } from '@/lib/utils';
import type { Profile, UserRole } from '@/types';

export function ManageUsersPage() {
  const { profile: currentUser } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'all'>('all');
  const [updating, setUpdating] = useState<string | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: err } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      if (err) throw err;
      setUsers((data as Profile[]) || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load users.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    setUpdating(userId);
    try {
      const { error: err } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', userId);
      if (err) throw err;
      setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u)));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to update role.');
    } finally {
      setUpdating(null);
    }
  };

  const filtered = users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return u.full_name.toLowerCase().includes(q) ||
        (u.phone || '').includes(q) ||
        (u.zone || '').toLowerCase().includes(q);
    }
    return true;
  });

  const roleCounts = {
    all: users.length,
    citizen: users.filter((u) => u.role === 'citizen').length,
    collector: users.filter((u) => u.role === 'collector').length,
    admin: users.filter((u) => u.role === 'admin').length,
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorState message={error} onRetry={fetchUsers} />;

  return (
    <div className="animate-fade-in">
      <PageHeader title="Manage Users" subtitle={`${users.length} registered users`} />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <input
          className="input pl-10"
          placeholder="Search by name, phone, or zone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="flex items-center gap-2 mb-6">
        {(['all', 'citizen', 'collector', 'admin'] as const).map((r) => (
          <button
            key={r}
            onClick={() => setRoleFilter(r)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium capitalize transition-all ${
              roleFilter === r
                ? 'bg-primary-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {r === 'all' ? 'All' : `${r}s`}
            <span className={`ml-1.5 text-xs ${roleFilter === r ? 'text-primary-100' : 'text-slate-400'}`}>
              {roleCounts[r]}
            </span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Users className="h-7 w-7" />}
          title="No users found"
          message={search || roleFilter !== 'all' ? 'Try adjusting your search or filter.' : 'No users have registered yet.'}
        />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wider">User</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wider">Role</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wider hidden sm:table-cell">Zone</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wider hidden md:table-cell">Phone</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wider hidden lg:table-cell">Joined</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((u, i) => {
                  const isSelf = u.id === currentUser?.id;
                  return (
                    <motion.tr
                      key={u.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.2, delay: i * 0.03 }}
                      className="hover:bg-slate-50"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-100 text-primary-700 text-xs font-semibold shrink-0">
                            {initialFromName(u.full_name)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-medium text-slate-900 truncate">
                              {u.full_name}
                              {isSelf && <span className="ml-1.5 text-xs text-primary-600">(You)</span>}
                            </p>
                            <p className="text-xs text-slate-400 sm:hidden">{u.zone || 'No zone'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {isSelf ? (
                          <span className="badge" style={{ color: ROLE_META[u.role].color, backgroundColor: `${ROLE_META[u.role].color}1a` }}>
                            <ShieldCheck className="h-3 w-3" /> {ROLE_META[u.role].label}
                          </span>
                        ) : (
                          <select
                            value={u.role}
                            disabled={updating === u.id}
                            onChange={(e) => handleRoleChange(u.id, e.target.value as UserRole)}
                            className={classNames(
                              'px-2.5 py-1 rounded-lg text-xs font-medium border-0 cursor-pointer transition-colors',
                              updating === u.id && 'opacity-50'
                            )}
                            style={{
                              color: ROLE_META[u.role as UserRole].color,
                              backgroundColor: `${ROLE_META[u.role as UserRole].color}1a`,
                            }}
                          >
                            <option value="citizen">Citizen</option>
                            <option value="collector">Collector</option>
                            <option value="admin">Admin</option>
                          </select>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-600 hidden sm:table-cell">{u.zone || '—'}</td>
                      <td className="px-4 py-3 text-slate-600 hidden md:table-cell">{u.phone || '—'}</td>
                      <td className="px-4 py-3 text-slate-500 text-xs hidden lg:table-cell">{formatDate(u.created_at)}</td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
