import { useNavigate } from 'react-router-dom';
import { Map as MapIcon, Navigation } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { MapView } from '@/components/MapView';
import { EmptyState, LoadingSpinner } from '@/components/ui';
import { STATUS_META } from '@/lib/constants';

export function AdminLiveMapPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const { complaints, loading } = useComplaints({
    query: 'all',
    userId: profile!.id,
    limit: 200,
  });

  const geoComplaints = complaints.filter((c) => c.latitude != null && c.longitude != null);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Live Complaint Map"
        subtitle={`${geoComplaints.length} complaints with location data`}
      />

      {/* Legend */}
      <div className="card p-4 mb-4">
        <div className="flex items-center flex-wrap gap-4 text-xs">
          <span className="font-semibold text-slate-700">Status Legend:</span>
          {(Object.keys(STATUS_META) as (keyof typeof STATUS_META)[]).map((s) => (
            <span key={s} className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: STATUS_META[s].color }} />
              <span className="text-slate-600">{STATUS_META[s].label}</span>
            </span>
          ))}
        </div>
      </div>

      {geoComplaints.length === 0 ? (
        <EmptyState
          icon={<MapIcon className="h-7 w-7" />}
          title="No complaints on the map"
          message="No complaints have GPS coordinates yet. The map will show complaint locations as citizens report them with location data."
        />
      ) : (
        <div className="space-y-4">
          <MapView complaints={geoComplaints} height="600px" zoom={13} onMarkerClick={(id) => navigate(`/complaints/${id}`)} />

          <div className="card p-4">
            <h3 className="font-semibold text-slate-900 mb-3">All Locations ({geoComplaints.length})</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {geoComplaints.map((c) => {
                const meta = STATUS_META[c.status];
                return (
                  <div
                    key={c.id}
                    onClick={() => navigate(`/complaints/${c.id}`)}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-900 text-sm">{c.complaint_code}</p>
                      <p className="text-xs text-slate-500 truncate">{c.address || `${c.latitude}, ${c.longitude}`}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{c.waste_type} • {c.citizen?.full_name}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="badge" style={{ color: meta.color, backgroundColor: meta.bg }}>{meta.label}</span>
                      <a
                        href={`https://www.openstreetmap.org/directions?from=&to=${c.latitude}%2C${c.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 rounded-lg text-primary-600 hover:bg-primary-50"
                      >
                        <Navigation className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
