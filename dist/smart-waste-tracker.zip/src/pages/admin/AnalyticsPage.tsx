import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3, TrendingUp, FileText, FileSpreadsheet, Award, Download,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, RadialBarChart, RadialBar,
} from 'recharts';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { LoadingSpinner } from '@/components/ui';
import { exportComplaintsPDF, exportComplaintsExcel } from '@/lib/export';
import { getComplaintStats, getCleanlinessScore } from '@/lib/utils';
import { WASTE_TYPES, STATUS_META } from '@/lib/constants';
import { format, subDays, isSameDay, startOfWeek, endOfWeek } from 'date-fns';

type Period = 'daily' | 'weekly' | 'monthly';

export function AnalyticsPage() {
  const { profile } = useAuth();
  const [period, setPeriod] = useState<Period>('daily');
  const { complaints, loading } = useComplaints({
    query: 'all',
    userId: profile!.id,
    limit: 500,
  });

  const stats = getComplaintStats(complaints);
  const score = getCleanlinessScore(complaints);

  // Period-based trend data
  const trendData = useMemo(() => {
    if (period === 'daily') {
      return Array.from({ length: 14 }, (_, i) => {
        const date = subDays(new Date(), 13 - i);
        return {
          label: format(date, 'MMM d'),
          reported: complaints.filter((c) => isSameDay(new Date(c.created_at), date)).length,
          completed: complaints.filter((c) => c.completed_at && isSameDay(new Date(c.completed_at), date)).length,
        };
      });
    }
    if (period === 'weekly') {
      return Array.from({ length: 8 }, (_, i) => {
        const weekStart = startOfWeek(subDays(new Date(), (7 - i) * 7));
        const weekEnd = endOfWeek(weekStart);
        return {
          label: `W${i + 1}`,
          reported: complaints.filter((c) => {
            const d = new Date(c.created_at);
            return d >= weekStart && d <= weekEnd;
          }).length,
          completed: complaints.filter((c) => {
            if (!c.completed_at) return false;
            const d = new Date(c.completed_at);
            return d >= weekStart && d <= weekEnd;
          }).length,
        };
      });
    }
    // monthly — last 6 months
    return Array.from({ length: 6 }, (_, i) => {
      const refDate = subDays(new Date(), (5 - i) * 30);
      const month = refDate.getMonth();
      const year = refDate.getFullYear();
      return {
        label: format(refDate, 'MMM'),
        reported: complaints.filter((c) => {
          const d = new Date(c.created_at);
          return d.getMonth() === month && d.getFullYear() === year;
        }).length,
        completed: complaints.filter((c) => {
          if (!c.completed_at) return false;
          const d = new Date(c.completed_at);
          return d.getMonth() === month && d.getFullYear() === year;
        }).length,
      };
    });
  }, [complaints, period]);

  // Waste type distribution
  const wasteTypeData = WASTE_TYPES.map((wt) => ({
    name: wt.value,
    value: complaints.filter((c) => c.waste_type === wt.value).length,
    color: wt.color,
  })).filter((d) => d.value > 0);

  // Status distribution
  const statusData = (Object.keys(STATUS_META) as (keyof typeof STATUS_META)[])
    .map((s) => ({
      name: STATUS_META[s].label,
      value: complaints.filter((c) => c.status === s).length,
      color: STATUS_META[s].color,
    }))
    .filter((d) => d.value > 0);

  // Urgency distribution
  const urgencyData = [
    { name: 'Low', value: complaints.filter((c) => c.urgency === 'Low').length, color: '#16a34a' },
    { name: 'Medium', value: complaints.filter((c) => c.urgency === 'Medium').length, color: '#ca8a04' },
    { name: 'High', value: complaints.filter((c) => c.urgency === 'High').length, color: '#ea580c' },
    { name: 'Critical', value: complaints.filter((c) => c.urgency === 'Critical').length, color: '#dc2626' },
  ].filter((d) => d.value > 0);

  // Collection efficiency (completed / total)
  const efficiency = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
  const radialData = [{ name: 'Efficiency', value: efficiency, fill: '#16a34a' }];

  if (loading) return <LoadingSpinner />;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Analytics & Reports"
        subtitle="Waste collection insights and trends"
        action={
          <div className="flex gap-2">
            <button onClick={() => exportComplaintsPDF(complaints, 'Analytics Report')} className="btn-secondary text-sm">
              <FileText className="h-4 w-4" /> PDF
            </button>
            <button onClick={() => exportComplaintsExcel(complaints, 'Analytics Report')} className="btn-secondary text-sm">
              <FileSpreadsheet className="h-4 w-4" /> Excel
            </button>
          </div>
        }
      />

      {/* Period selector */}
      <div className="flex items-center gap-2 mb-6">
        {(['daily', 'weekly', 'monthly'] as Period[]).map((p) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition-all ${
              period === p
                ? 'bg-primary-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {p} Report
          </button>
        ))}
      </div>

      {/* Score + efficiency */}
      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        <div className="card p-5 bg-gradient-to-br from-primary-50 to-emerald-50 border-primary-100">
          <div className="flex items-center gap-3 mb-2">
            <Award className="h-6 w-6 text-primary-600" />
            <h3 className="font-semibold text-slate-900">Cleanliness Score</h3>
          </div>
          <p className="font-display text-4xl font-bold text-slate-900">{score}<span className="text-xl text-slate-400">/100</span></p>
          <p className="text-xs text-slate-500 mt-1">
            {score >= 80 ? 'Excellent — village is very clean' : score >= 60 ? 'Good — minor improvements needed' : score >= 40 ? 'Needs attention' : 'Critical — urgent action required'}
          </p>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-3">Collection Efficiency</h3>
          <ResponsiveContainer width="100%" height={140}>
            <RadialBarChart data={radialData} innerRadius="55%" outerRadius="90%" startAngle={90} endAngle={-270}>
              <RadialBar dataKey="value" cornerRadius={10} fill="#16a34a" background />
              <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="font-bold" fill="#16a34a" fontSize="22">
                {efficiency}%
              </text>
            </RadialBarChart>
          </ResponsiveContainer>
          <p className="text-xs text-slate-500 text-center">{stats.completed} completed of {stats.total}</p>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-3">Quick Stats</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><p className="text-xs text-slate-400">Total</p><p className="font-bold text-slate-900 text-lg">{stats.total}</p></div>
            <div><p className="text-xs text-slate-400">Pending</p><p className="font-bold text-amber-600 text-lg">{stats.pending}</p></div>
            <div><p className="text-xs text-slate-400">Active</p><p className="font-bold text-cyan-600 text-lg">{stats.assigned + stats.inProgress}</p></div>
            <div><p className="text-xs text-slate-400">Rejected</p><p className="font-bold text-red-600 text-lg">{stats.rejected}</p></div>
          </div>
        </div>
      </div>

      {/* Trend chart */}
      <div className="card p-5 mb-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-slate-400" /> Complaint Trends ({period})
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="#94a3b8" />
            <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" allowDecimals={false} />
            <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey="reported" name="Reported" stroke="#16a34a" strokeWidth={2} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="completed" name="Completed" stroke="#0891b2" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Waste type */}
        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-slate-400" /> Waste Type Distribution
          </h3>
          {wasteTypeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={wasteTypeData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                  {wasteTypeData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-sm text-slate-400">No data</div>
          )}
        </div>

        {/* Status */}
        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-slate-400" /> Status Distribution
          </h3>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {statusData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-sm text-slate-400">No data</div>
          )}
        </div>
      </div>

      {/* Urgency distribution */}
      <div className="card p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-slate-400" /> Urgency Levels
        </h3>
        {urgencyData.length > 0 ? (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={urgencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {urgencyData.map((d) => (
                  <Cell key={d.name} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[200px] flex items-center justify-center text-sm text-slate-400">No data</div>
        )}
      </div>
    </div>
  );
}
