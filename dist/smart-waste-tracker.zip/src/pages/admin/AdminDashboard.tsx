import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ClipboardList, Clock, CheckCircle2, AlertCircle, FileText,
  Download, FileSpreadsheet, Users, Map as MapIcon, TrendingUp, Award,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, Area, AreaChart,
} from 'recharts';
import { useAuth } from '@/context/AuthContext';
import { useComplaints } from '@/hooks/useComplaints';
import { PageHeader } from '@/components/DashboardLayout';
import { StatCard, EmptyState, LoadingSpinner } from '@/components/ui';
import { ComplaintCard } from '@/components/ComplaintCard';
import { MapView } from '@/components/MapView';
import { getComplaintStats, getCleanlinessScore } from '@/lib/utils';
import { WASTE_TYPES } from '@/lib/constants';
import { exportComplaintsPDF, exportComplaintsExcel } from '@/lib/export';
import { format, subDays, startOfDay, isSameDay } from 'date-fns';

export function AdminDashboard() {
  const { profile } = useAuth();
  const { complaints, loading } = useComplaints({
    query: 'all',
    userId: profile!.id,
    limit: 100,
  });

  if (loading) return <LoadingSpinner />;

  const stats = getComplaintStats(complaints);
  const score = getCleanlinessScore(complaints);

  // Waste type distribution
  const wasteTypeData = WASTE_TYPES.map((wt) => ({
    name: wt.value,
    value: complaints.filter((c) => c.waste_type === wt.value).length,
    color: wt.color,
  })).filter((d) => d.value > 0);

  // Complaint trends (last 7 days)
  const trendData = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayComplaints = complaints.filter((c) => isSameDay(new Date(c.created_at), date));
    const completed = complaints.filter((c) => c.completed_at && isSameDay(new Date(c.completed_at), date));
    return {
      date: format(date, 'EEE'),
      reported: dayComplaints.length,
      completed: completed.length,
    };
  });

  // Status distribution
  const statusData = [
    { name: 'Pending', value: stats.pending, color: '#ca8a04' },
    { name: 'Assigned', value: stats.assigned, color: '#2563eb' },
    { name: 'In Progress', value: stats.inProgress, color: '#0891b2' },
    { name: 'Completed', value: stats.completed, color: '#16a34a' },
    { name: 'Rejected', value: stats.rejected, color: '#dc2626' },
  ].filter((d) => d.value > 0);

  const geoComplaints = complaints.filter((c) => c.latitude != null && c.longitude != null);
  const recentComplaints = complaints.slice(0, 5);

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Admin Dashboard"
        subtitle="Real-time monitoring and analytics"
        action={
          <div className="flex gap-2">
            <button onClick={() => exportComplaintsPDF(complaints)} className="btn-secondary text-sm">
              <FileText className="h-4 w-4" /> PDF
            </button>
            <button onClick={() => exportComplaintsExcel(complaints)} className="btn-secondary text-sm">
              <FileSpreadsheet className="h-4 w-4" /> Excel
            </button>
          </div>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total" value={stats.total} icon={<ClipboardList className="h-5 w-5" />} color="#16a34a" />
        <StatCard label="Pending" value={stats.pending} icon={<Clock className="h-5 w-5" />} color="#ca8a04" />
        <StatCard label="Assigned" value={stats.assigned} icon={<AlertCircle className="h-5 w-5" />} color="#2563eb" />
        <StatCard label="Completed" value={stats.completed} icon={<CheckCircle2 className="h-5 w-5" />} color="#16a34a" />
      </div>

      {/* Cleanliness score banner */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-5 mb-6 bg-gradient-to-br from-primary-50 to-emerald-50 border-primary-100"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-100 text-primary-600">
              <Award className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Village Cleanliness Score</p>
              <p className="font-display text-3xl font-bold text-slate-900">{score}<span className="text-lg text-slate-400">/100</span></p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-500">
              {score >= 80 ? 'Excellent' : score >= 60 ? 'Good' : score >= 40 ? 'Needs Attention' : 'Critical'}
            </p>
            <p className="text-xs text-slate-400">{stats.completed} of {stats.total} resolved</p>
          </div>
        </div>
      </motion.div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Trend chart */}
        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-slate-400" /> Complaint Trends (7 days)
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorReported" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#16a34a" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0891b2" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#0891b2" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="reported" name="Reported" stroke="#16a34a" fillOpacity={1} fill="url(#colorReported)" />
              <Area type="monotone" dataKey="completed" name="Completed" stroke="#0891b2" fillOpacity={1} fill="url(#colorCompleted)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Waste type pie */}
        <div className="card p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <FileText className="h-4 w-4 text-slate-400" /> Waste Type Statistics
          </h3>
          {wasteTypeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={wasteTypeData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} innerRadius={45}>
                  {wasteTypeData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[240px] flex items-center justify-center text-sm text-slate-400">No data yet</div>
          )}
        </div>
      </div>

      {/* Status distribution bar */}
      <div className="card p-5 mb-6">
        <h3 className="font-semibold text-slate-900 mb-4">Complaint Status Distribution</h3>
        {statusData.length > 0 ? (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={statusData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {statusData.map((d) => (
                  <Cell key={d.name} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[200px] flex items-center justify-center text-sm text-slate-400">No data yet</div>
        )}
      </div>

      {/* Live map */}
      <div className="card p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <MapIcon className="h-4 w-4 text-slate-400" /> Live Complaint Map
          </h3>
          <Link to="/admin/map" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
            Full screen
          </Link>
        </div>
        {geoComplaints.length > 0 ? (
          <MapView complaints={geoComplaints} height="400px" zoom={13} />
        ) : (
          <div className="h-[400px] flex items-center justify-center text-sm text-slate-400">
            No complaints with location data yet
          </div>
        )}
      </div>

      {/* Recent complaints */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-slate-900">Recent Complaints</h3>
        <Link to="/admin/complaints" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
          View all
        </Link>
      </div>

      {recentComplaints.length === 0 ? (
        <EmptyState
          icon={<ClipboardList className="h-7 w-7" />}
          title="No complaints yet"
          message="When citizens report waste issues, they will appear here for you to review and assign."
        />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {recentComplaints.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <ComplaintCard complaint={c} to={`/complaints/${c.id}`} showCitizen showCollector />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
