import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Camera, MapPin, Bell, BarChart3, Users, FileText, ShieldCheck, Recycle, ArrowRight,
} from 'lucide-react';

const services = [
  {
    icon: Camera,
    title: 'Waste Issue Reporting',
    desc: 'Citizens report garbage problems with photos, waste type selection, urgency levels, and descriptions — all from their phone.',
    features: ['Photo upload (JPG/PNG)', 'Waste type categorization', 'Urgency marking', 'Auto GPS capture'],
  },
  {
    icon: MapPin,
    title: 'GPS Location & Mapping',
    desc: 'Every complaint is automatically geo-tagged and displayed on an interactive map for admins and collectors to navigate.',
    features: ['Automatic lat/long capture', 'Interactive village map', 'Route navigation for collectors', 'Live complaint markers'],
  },
  {
    icon: ShieldCheck,
    title: 'Admin Monitoring',
    desc: 'Administrators get a real-time dashboard with total, pending, assigned, and completed complaint stats plus a live map.',
    features: ['Real-time complaint stats', 'Live map overview', 'Collector assignment', 'User management'],
  },
  {
    icon: BarChart3,
    title: 'Analytics & Reports',
    desc: 'Generate daily, weekly, and monthly reports with waste-type statistics, complaint trends, and a village cleanliness score.',
    features: ['Waste type statistics', 'Complaint trend charts', 'PDF/Excel export', 'Cleanliness score'],
  },
  {
    icon: Bell,
    title: 'Notifications',
    desc: 'In-app notifications keep everyone informed — citizens when their issue is resolved, collectors when assigned a new task.',
    features: ['Assignment alerts', 'Status change updates', 'Completion notifications', 'Unread badge counter'],
  },
  {
    icon: Recycle,
    title: 'Collection Workflow',
    desc: 'Collectors receive assigned complaints, update status to In Progress, upload before/after photos, and mark completed.',
    features: ['Assigned task list', 'Status updates', 'Before/after photos', 'Collection time logging'],
  },
];

const roles = [
  { icon: Users, title: 'For Citizens', desc: 'Report waste, track your complaints, and get notified when resolved.', to: '/signup' },
  { icon: ShieldCheck, title: 'For Collectors', desc: 'Get assigned tasks, navigate to locations, update status with photos.', to: '/signup' },
  { icon: BarChart3, title: 'For Admins', desc: 'Monitor everything, assign collectors, view analytics, export reports.', to: '/signup' },
];

export function ServicesPage() {
  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-50 to-emerald-50 py-16 lg:py-20">
        <div className="container-app px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="badge bg-primary-100 text-primary-700 mb-4">
              <FileText className="h-3.5 w-3.5" /> Our Services
            </span>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-slate-900">
              One platform, <span className="text-gradient">complete coverage</span>
            </h1>
            <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
              From reporting to collection to analytics — every service a village needs
              to manage waste intelligently.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="card card-hover p-6"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 mb-4">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">{s.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed mb-4">{s.desc}</p>
                <ul className="space-y-1.5">
                  {s.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary-400" /> {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16 lg:py-24">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <h2 className="font-display text-3xl font-bold text-slate-900 text-center mb-12">
            Built for everyone in the village
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {roles.map((r, i) => (
              <motion.div
                key={r.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="card p-6 text-center group"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50 text-primary-600 mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <r.icon className="h-7 w-7" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">{r.title}</h3>
                <p className="text-sm text-slate-600 mb-4">{r.desc}</p>
                <Link to={r.to} className="text-sm text-primary-600 font-medium inline-flex items-center gap-1 hover:text-primary-700">
                  Get started <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
