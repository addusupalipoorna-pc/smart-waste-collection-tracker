import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Leaf, MapPin, Camera, Bell, BarChart3, Users, ArrowRight,
  Trash2, Recycle, ShieldCheck, Clock, CheckCircle2, Sprout,
} from 'lucide-react';

const features = [
  { icon: Camera, title: 'Photo Reporting', desc: 'Citizens snap photos of waste issues and submit in seconds with automatic GPS location tagging.' },
  { icon: MapPin, title: 'Live GPS Map', desc: 'Every complaint is plotted on an interactive map so admins and collectors see exactly where to go.' },
  { icon: Bell, title: 'Real-time Notifications', desc: 'Collectors get assigned instantly. Citizens get notified the moment their issue is resolved.' },
  { icon: BarChart3, title: 'Analytics & Reports', desc: 'Admins track waste trends, cleanliness scores, and export PDF/Excel reports for review.' },
  { icon: Users, title: 'Three Role Portal', desc: 'Dedicated dashboards for citizens, collectors, and admins — each tuned to what they need.' },
  { icon: Recycle, title: 'Waste Type Tracking', desc: 'Categorize by plastic, organic, e-waste, medical, and more to identify village waste patterns.' },
];

const steps = [
  { icon: Users, title: 'Register & Login', desc: 'Citizens, collectors, and admins each get a secure account.' },
  { icon: Camera, title: 'Report Issue', desc: 'Snap a photo, pick the waste type, set urgency, and GPS is captured.' },
  { icon: ShieldCheck, title: 'Admin Assigns', desc: 'Admins review complaints and assign them to nearby collectors.' },
  { icon: Trash2, title: 'Collector Cleans', desc: 'Collectors update status, upload before/after photos, and mark complete.' },
  { icon: CheckCircle2, title: 'Citizen Notified', desc: 'The reporter gets a notification: "Your waste issue has been resolved."' },
];

const stats = [
  { value: '7', label: 'Waste Categories' },
  { value: '3', label: 'Role Portals' },
  { value: '24/7', label: 'Monitoring' },
  { value: '100%', label: 'Transparent Tracking' },
];

export function LandingPage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-emerald-50" />
        <div
          className="absolute inset-0 opacity-30 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.pexels.com/photos/32664614/pexels-photo-32664614.jpeg?auto=compress&cs=tinysrgb&h=650&w=940')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/70 to-transparent" />

        <div className="relative container-app px-4 sm:px-6 lg:px-8 pt-20 pb-24 lg:pt-28 lg:pb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <span className="badge bg-primary-100 text-primary-700 mb-4">
              <Sprout className="h-3.5 w-3.5" /> Village Waste Management Platform
            </span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight">
              A Cleaner Village,<br />
              <span className="text-gradient">Starting with a Photo.</span>
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed max-w-2xl">
              Smart Waste Collection Tracker empowers villagers to report waste issues,
              helps sanitation workers collect efficiently, and gives administrators
              real-time monitoring and analytics — all in one intelligent platform.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <Link to="/signup" className="btn-primary text-base px-6 py-3">
                Get Started Free <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/about" className="btn-secondary text-base px-6 py-3">
                Learn More
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {stats.map((s) => (
              <div key={s.label} className="glass rounded-2xl p-5 text-center">
                <p className="font-display text-3xl font-bold text-primary-600">{s.value}</p>
                <p className="text-xs text-slate-600 mt-1">{s.label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="section-padding">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">
              Everything a village needs to stay clean
            </h2>
            <p className="mt-4 text-slate-600">
              From the moment a citizen spots a waste pile to the moment it's collected —
              every step is tracked, logged, and analyzed.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="card card-hover p-6"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 mb-4">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">{f.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="bg-slate-50 py-16 lg:py-24">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">
              How it works
            </h2>
            <p className="mt-4 text-slate-600">Five simple steps from report to resolution.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {steps.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="card p-5 text-center relative"
              >
                <span className="absolute -top-3 -right-3 flex h-7 w-7 items-center justify-center rounded-full bg-primary-600 text-white text-xs font-bold">
                  {i + 1}
                </span>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 mx-auto mb-3">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-slate-900 text-sm mb-1">{s.title}</h3>
                <p className="text-xs text-slate-500">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-primary-600 to-emerald-700 p-8 sm:p-12 lg:p-16 text-center">
            <Leaf className="absolute top-6 right-6 h-20 w-20 text-white/10" />
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white max-w-2xl mx-auto">
              Ready to make your village cleaner?
            </h2>
            <p className="mt-4 text-primary-50 max-w-xl mx-auto">
              Join as a citizen to report issues, a collector to manage tasks, or an admin to oversee operations.
            </p>
            <Link to="/signup" className="inline-flex items-center gap-2 mt-8 bg-white text-primary-700 font-semibold px-6 py-3 rounded-xl hover:bg-primary-50 transition-colors">
              Create Your Account <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
