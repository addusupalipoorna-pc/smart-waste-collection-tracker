import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageSquare, CheckCircle2 } from 'lucide-react';

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setForm({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSubmitted(false), 5000);
  };

  const contactInfo = [
    { icon: Mail, label: 'Email', value: 'support@smartwaste.gov', href: 'mailto:support@smartwaste.gov' },
    { icon: Phone, label: 'Phone', value: '1800-XXX-XXXX (Toll Free)', href: 'tel:1800XXXXXXX' },
    { icon: MapPin, label: 'Office', value: 'Gram Panchayat Office, Village Block', href: '#' },
  ];

  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-50 to-emerald-50 py-16 lg:py-20">
        <div className="container-app px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="badge bg-primary-100 text-primary-700 mb-4">
              <MessageSquare className="h-3.5 w-3.5" /> Get in Touch
            </span>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-slate-900">
              We'd love to <span className="text-gradient">hear from you</span>
            </h1>
            <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
              Questions, feedback, or want to bring SmartWaste to your village? Reach out.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-6">
            {contactInfo.map((c) => (
              <a
                key={c.label}
                href={c.href}
                className="card card-hover p-6 text-center"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 mx-auto mb-3">
                  <c.icon className="h-6 w-6" />
                </div>
                <p className="text-xs text-slate-500 uppercase tracking-wider font-medium">{c.label}</p>
                <p className="text-sm font-semibold text-slate-900 mt-1">{c.value}</p>
              </a>
            ))}
          </div>

          <div className="mt-10 grid lg:grid-cols-2 gap-8">
            <div className="card p-6 lg:p-8">
              <h2 className="font-display text-2xl font-bold text-slate-900 mb-2">Send us a message</h2>
              <p className="text-sm text-slate-500 mb-6">We typically respond within 1-2 business days.</p>

              {submitted && (
                <div className="mb-4 p-4 rounded-xl bg-primary-50 border border-primary-200 flex items-center gap-2 animate-fade-in">
                  <CheckCircle2 className="h-5 w-5 text-primary-600" />
                  <p className="text-sm text-primary-700">Thank you! Your message has been received.</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Full Name</label>
                    <input
                      required
                      className="input"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="label">Email</label>
                    <input
                      required
                      type="email"
                      className="input"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="you@example.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="label">Subject</label>
                  <input
                    required
                    className="input"
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    placeholder="What's this about?"
                  />
                </div>
                <div>
                  <label className="label">Message</label>
                  <textarea
                    required
                    rows={5}
                    className="input resize-none"
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Tell us more..."
                  />
                </div>
                <button type="submit" className="btn-primary w-full">
                  <Send className="h-4 w-4" /> Send Message
                </button>
              </form>
            </div>

            <div className="card p-6 lg:p-8 bg-gradient-to-br from-primary-600 to-emerald-700 text-white">
              <h3 className="font-display text-xl font-bold mb-4">Why villages choose SmartWaste</h3>
              <ul className="space-y-4">
                {[
                  'Free and production-ready — no expensive setup.',
                  'Works on any phone with a browser and GPS.',
                  'Citizens, collectors, and admins each get tailored tools.',
                  'Real-time maps and analytics for transparency.',
                  'Exportable reports for panchayat meetings and audits.',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle2 className="h-5 w-5 text-primary-200 shrink-0 mt-0.5" />
                    <span className="text-sm text-primary-50">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
