import { motion } from 'framer-motion';
import { Target, Eye, Heart, Leaf, Users, BarChart3 } from 'lucide-react';

const values = [
  { icon: Target, title: 'Our Mission', desc: 'To empower rural communities with technology that makes waste management transparent, efficient, and participatory — turning every villager into a guardian of their environment.' },
  { icon: Eye, title: 'Our Vision', desc: 'Clean, healthy villages where waste is reported, collected, and managed in real time — supported by data-driven decisions and community engagement.' },
  { icon: Heart, title: 'Our Values', desc: 'Community first, environmental responsibility, transparency in governance, and accessible technology for everyone — regardless of technical literacy.' },
];

const objectives = [
  'Enable citizens to report waste issues with photo and GPS evidence in under a minute.',
  'Reduce the gap between waste reporting and collection through instant assignment.',
  'Provide administrators with real-time dashboards and downloadable reports.',
  'Track waste-type trends to inform long-term sanitation policy and infrastructure.',
  'Foster community participation in maintaining village cleanliness.',
  'Generate a measurable Village Cleanliness Score from real complaint data.',
];

export function AboutPage() {
  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-50 to-emerald-50 py-16 lg:py-24">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl"
          >
            <span className="badge bg-primary-100 text-primary-700 mb-4">
              <Leaf className="h-3.5 w-3.5" /> About the Project
            </span>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-slate-900">
              Waste Management in Villages:<br />
              <span className="text-gradient">A Survey on Disposal Methods</span>
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Smart Waste Collection Tracker is an intelligent web application born from a
              simple observation: villages lack a structured way to report, track, and resolve
              waste issues. This platform bridges that gap — connecting citizens, sanitation
              workers, and administrators on one digital platform.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            {values.map((v, i) => (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="card card-hover p-6"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 mb-4">
                  <v.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">{v.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16 lg:py-24">
        <div className="container-app px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-display text-3xl font-bold text-slate-900 mb-4">Project Objectives</h2>
              <p className="text-slate-600 mb-6">
                The platform is designed around a clear, end-to-end workflow — from complaint
                to collection to confirmation — with analytics that help villages make informed
                sanitation decisions.
              </p>
              <ul className="space-y-3">
                {objectives.map((obj, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary-100 text-primary-700 text-xs font-bold mt-0.5">
                      {i + 1}
                    </span>
                    <span className="text-sm text-slate-700">{obj}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="card p-6 text-center">
                <Users className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <p className="font-display text-2xl font-bold text-slate-900">3 Roles</p>
                <p className="text-xs text-slate-500">Citizen, Collector, Admin</p>
              </div>
              <div className="card p-6 text-center">
                <BarChart3 className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <p className="font-display text-2xl font-bold text-slate-900">Analytics</p>
                <p className="text-xs text-slate-500">Charts, trends, exports</p>
              </div>
              <div className="card p-6 text-center">
                <Leaf className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <p className="font-display text-2xl font-bold text-slate-900">7 Types</p>
                <p className="text-xs text-slate-500">Waste categories tracked</p>
              </div>
              <div className="card p-6 text-center">
                <Target className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <p className="font-display text-2xl font-bold text-slate-900">Score</p>
                <p className="text-xs text-slate-500">Village cleanliness index</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
