import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, Phone, MapPin, Save, LogOut, CheckCircle2, AlertCircle, Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { PageHeader } from '@/components/DashboardLayout';
import { ROLE_META } from '@/lib/constants';
import { initialFromName, isValidEmail } from '@/lib/utils';

export function ProfilePage() {
  const { profile, updateProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState(profile!.full_name);
  const [phone, setPhone] = useState(profile!.phone || '');
  const [zone, setZone] = useState(profile!.zone || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!profile) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (fullName.trim().length < 2) {
      setError('Name is too short.');
      return;
    }
    setSaving(true);
    const { error: err } = await updateProfile({
      full_name: fullName.trim(),
      phone: phone || null,
      zone: zone || null,
    });
    setSaving(false);
    if (err) {
      setError(err);
    } else {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const roleMeta = ROLE_META[profile.role];

  return (
    <div className="animate-fade-in max-w-2xl mx-auto">
      <PageHeader title="My Profile" subtitle="Manage your account information" />

      {/* Profile header card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-6 mb-6"
      >
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-emerald-600 text-white text-xl font-bold shadow-lg shadow-primary-500/20">
            {initialFromName(profile.full_name)}
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900">{profile.full_name}</h2>
            <span className="badge mt-1" style={{ color: roleMeta.color, backgroundColor: `${roleMeta.color}1a` }}>
              <Shield className="h-3 w-3" /> {roleMeta.label}
            </span>
            <p className="text-xs text-slate-400 mt-1">Member since {new Date(profile.created_at).toLocaleDateString()}</p>
          </div>
        </div>
      </motion.div>

      {/* Edit form */}
      <form onSubmit={handleSave} className="card p-6 mb-6">
        <h3 className="font-semibold text-slate-900 mb-4">Edit Information</h3>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2">
            <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}
        {saved && (
          <div className="mb-4 p-3 rounded-xl bg-primary-50 border border-primary-200 flex items-start gap-2 animate-fade-in">
            <CheckCircle2 className="h-4 w-4 text-primary-600 mt-0.5 shrink-0" />
            <p className="text-sm text-primary-700">Profile updated successfully.</p>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="label">Full Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                className="input pl-10"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your full name"
              />
            </div>
          </div>
          <div>
            <label className="label">Email <span className="text-slate-400 font-normal">(cannot change)</span></label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                className="input pl-10 bg-slate-50 text-slate-500"
                value={profile.id ? '(from auth)' : ''}
                disabled
                placeholder="Email is managed by your login"
              />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Phone</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  className="input pl-10"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 XXXXX XXXXX"
                />
              </div>
            </div>
            <div>
              <label className="label">Village / Zone</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  className="input pl-10"
                  value={zone}
                  onChange={(e) => setZone(e.target.value)}
                  placeholder="e.g., Ward 1, North Zone"
                />
              </div>
            </div>
          </div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary mt-5">
          {saving ? (
            <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <><Save className="h-4 w-4" /> Save Changes</>
          )}
        </button>
      </form>

      {/* Danger zone */}
      <div className="card p-6">
        <h3 className="font-semibold text-slate-900 mb-2">Session</h3>
        <p className="text-sm text-slate-500 mb-4">Sign out of your account on this device.</p>
        <button onClick={handleSignOut} className="btn-ghost text-red-600 hover:bg-red-50">
          <LogOut className="h-4 w-4" /> Sign Out
        </button>
      </div>
    </div>
  );
}
