import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, MapPin, Clock, Camera, User, CheckCircle2, AlertCircle,
  Navigation, Loader2, Trash2, XCircle, PlayCircle, Flag,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { MapView } from '@/components/MapView';
import { PhotoUpload } from '@/components/PhotoUpload';
import { StatusBadge, UrgencyBadge } from '@/components/Badges';
import { LoadingSpinner, ErrorState } from '@/components/ui';
import { WASTE_TYPES, STATUS_META } from '@/lib/constants';
import { formatDateTime, timeAgo, classNames } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { sendNotification } from '@/lib/notifications';
import type { Complaint, Profile } from '@/types';

export function ComplaintDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [collectors, setCollectors] = useState<Profile[]>([]);
  const [selectedCollector, setSelectedCollector] = useState<string>('');
  const [adminNotes, setAdminNotes] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [collectionPhotos, setCollectionPhotos] = useState<string[]>([]);
  const [completionPhotos, setCompletionPhotos] = useState<string[]>([]);
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  const fetchComplaint = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const { data, error: err } = await supabase
        .from('complaints')
        .select(`
          *,
          citizen:profiles!complaints_citizen_id_fkey(id, full_name, role, zone, phone),
          assigned_collector:profiles!complaints_assigned_collector_id_fkey(id, full_name, role, zone, phone)
        `)
        .eq('id', id)
        .maybeSingle();

      if (err) throw err;
      if (!data) {
        setError('Complaint not found.');
        return;
      }
      setComplaint(data as Complaint);
      setCollectionPhotos((data as Complaint).collection_photos || []);
      setCompletionPhotos((data as Complaint).completion_photos || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load complaint.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaint();
  }, [id]);

  // Admin: fetch available collectors
  useEffect(() => {
    if (profile?.role === 'admin') {
      supabase
        .from('profiles')
        .select('*')
        .eq('role', 'collector')
        .order('full_name')
        .then(({ data }) => setCollectors((data as Profile[]) || []));
    }
  }, [profile?.role]);

  const wasteType = complaint ? WASTE_TYPES.find((w) => w.value === complaint.waste_type) : null;

  // === Admin actions ===
  const handleAssign = async () => {
    if (!complaint || !selectedCollector) return;
    setActionLoading(true);
    try {
      const { error: err } = await supabase
        .from('complaints')
        .update({ assigned_collector_id: selectedCollector, status: 'Assigned', admin_notes: adminNotes || null })
        .eq('id', complaint.id);
      if (err) throw err;

      await sendNotification(
        selectedCollector,
        'New Task Assigned',
        `You've been assigned complaint ${complaint.complaint_code} (${complaint.waste_type} waste).`,
        'assignment',
        complaint.id
      );
      await sendNotification(
        complaint.citizen_id,
        'Collector Assigned',
        `Your complaint ${complaint.complaint_code} has been assigned to a collector.`,
        'status',
        complaint.id
      );
      await fetchComplaint();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to assign collector.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!complaint || !confirm('Reject this complaint?')) return;
    setActionLoading(true);
    try {
      const { error: err } = await supabase
        .from('complaints')
        .update({ status: 'Rejected', admin_notes: adminNotes || null })
        .eq('id', complaint.id);
      if (err) throw err;
      await sendNotification(
        complaint.citizen_id,
        'Complaint Rejected',
        `Your complaint ${complaint.complaint_code} has been reviewed and rejected. ${adminNotes ? `Reason: ${adminNotes}` : ''}`,
        'status',
        complaint.id
      );
      await fetchComplaint();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to reject complaint.');
    } finally {
      setActionLoading(false);
    }
  };

  // === Collector actions ===
  const handleStartProgress = async () => {
    if (!complaint) return;
    setActionLoading(true);
    try {
      const { error: err } = await supabase
        .from('complaints')
        .update({ status: 'In Progress', started_at: new Date().toISOString() })
        .eq('id', complaint.id);
      if (err) throw err;
      await sendNotification(
        complaint.citizen_id,
        'Collection Started',
        `Your complaint ${complaint.complaint_code} is now being processed by the collector.`,
        'status',
        complaint.id
      );
      await fetchComplaint();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to update status.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleUploadCollectionPhotos = async () => {
    if (!complaint) return;
    setActionLoading(true);
    try {
      const { error: err } = await supabase
        .from('complaints')
        .update({ collection_photos: collectionPhotos })
        .eq('id', complaint.id);
      if (err) throw err;
      await fetchComplaint();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to upload photos.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleComplete = async () => {
    if (!complaint || completionPhotos.length === 0) {
      setError('Please upload at least one after-cleaning photo to mark as completed.');
      return;
    }
    setActionLoading(true);
    try {
      const { error: err } = await supabase
        .from('complaints')
        .update({
          status: 'Completed',
          completed_at: new Date().toISOString(),
          completion_photos: completionPhotos,
        })
        .eq('id', complaint.id);
      if (err) throw err;

      await sendNotification(
        complaint.citizen_id,
        'Waste Issue Resolved!',
        `Your reported waste issue (${complaint.complaint_code}) has been successfully resolved. Thank you for keeping our village clean.`,
        'completion',
        complaint.id
      );
      await fetchComplaint();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to mark as completed.');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading complaint..." />;
  if (error && !complaint) return <ErrorState message={error} onRetry={fetchComplaint} />;
  if (!complaint) return <ErrorState message="Complaint not found." />;

  const isAdmin = profile?.role === 'admin';
  const isCollector = profile?.role === 'collector' && complaint.assigned_collector_id === profile?.id;
  const isOwner = profile?.id === complaint.citizen_id;
  const canStartProgress = isCollector && complaint.status === 'Assigned';
  const canComplete = isCollector && complaint.status === 'In Progress';

  return (
    <div className="animate-fade-in max-w-4xl mx-auto">
      <Link
        to={-1 as unknown as string}
        onClick={(e) => { e.preventDefault(); navigate(-1); }}
        className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 mb-4"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {/* Header */}
      <div className="card p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="font-display text-2xl font-bold text-slate-900">{complaint.complaint_code}</h1>
              <StatusBadge status={complaint.status} />
            </div>
            <div className="flex items-center flex-wrap gap-2">
              <UrgencyBadge urgency={complaint.urgency} />
              <span
                className="badge text-white"
                style={{ backgroundColor: wasteType?.color }}
              >
                {complaint.waste_type} Waste
              </span>
            </div>
          </div>
          {isAdmin && (
            <button
              onClick={async () => {
                if (confirm('Delete this complaint permanently?')) {
                  await supabase.from('complaints').delete().eq('id', complaint.id);
                  navigate('/admin/complaints');
                }
              }}
              className="btn-ghost text-red-600 hover:bg-red-50 text-sm"
            >
              <Trash2 className="h-4 w-4" /> Delete
            </button>
          )}
        </div>
        <p className="text-slate-600 leading-relaxed">{complaint.description}</p>
        <div className="flex items-center flex-wrap gap-4 mt-4 text-xs text-slate-400">
          <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> Reported {timeAgo(complaint.created_at)}</span>
          {complaint.completed_at && (
            <span className="flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> Completed {timeAgo(complaint.completed_at)}</span>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left: photos + map */}
        <div className="lg:col-span-2 space-y-6">
          {/* Reported photos */}
          <div className="card p-5">
            <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Camera className="h-4 w-4 text-slate-400" /> Reported Photos ({complaint.photos.length})
            </h3>
            {complaint.photos.length > 0 ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {complaint.photos.map((p, i) => (
                  <button
                    key={i}
                    onClick={() => setActivePhoto(p)}
                    className="aspect-square rounded-xl overflow-hidden border border-slate-200 hover:ring-2 hover:ring-primary-400 transition-all"
                  >
                    <img src={p} alt={`Photo ${i + 1}`} className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-400">No photos uploaded.</p>
            )}
          </div>

          {/* Location */}
          {complaint.latitude != null && complaint.longitude != null && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <MapPin className="h-4 w-4 text-slate-400" /> Location
              </h3>
              <p className="text-sm text-slate-600 mb-3">{complaint.address || `${complaint.latitude}, ${complaint.longitude}`}</p>
              <MapView
                singleMarker={{ lat: complaint.latitude, lng: complaint.longitude, label: complaint.address || 'Complaint location' }}
                height="280px"
                zoom={15}
              />
              {(isCollector || isAdmin) && (
                <a
                  href={`https://www.openstreetmap.org/directions?from=&to=${complaint.latitude}%2C${complaint.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary mt-3 w-full text-sm"
                >
                  <Navigation className="h-4 w-4" /> Get Directions
                </a>
              )}
            </div>
          )}

          {/* Collection photos */}
          {(complaint.collection_photos.length > 0 || canStartProgress || canComplete) && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <Camera className="h-4 w-4 text-slate-400" /> Collection Photos
              </h3>
              {complaint.collection_photos.length > 0 && (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-4">
                  {complaint.collection_photos.map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setActivePhoto(p)}
                      className="aspect-square rounded-xl overflow-hidden border border-slate-200 hover:ring-2 hover:ring-primary-400"
                    >
                      <img src={p} alt={`Collection ${i + 1}`} className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
              {canComplete && (
                <div className="space-y-3">
                  <PhotoUpload photos={collectionPhotos} onChange={setCollectionPhotos} label="Add Collection Photos" />
                  {collectionPhotos.length > 0 && collectionPhotos.length !== complaint.collection_photos.length && (
                    <button onClick={handleUploadCollectionPhotos} disabled={actionLoading} className="btn-secondary text-sm">
                      {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save Collection Photos'}
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Completion photos */}
          {(complaint.completion_photos.length > 0 || canComplete) && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-slate-400" /> After-Cleaning Photos
              </h3>
              {complaint.completion_photos.length > 0 && (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-4">
                  {complaint.completion_photos.map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setActivePhoto(p)}
                      className="aspect-square rounded-xl overflow-hidden border border-slate-200 hover:ring-2 hover:ring-primary-400"
                    >
                      <img src={p} alt={`After ${i + 1}`} className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
              {canComplete && (
                <div className="space-y-3">
                  <PhotoUpload photos={completionPhotos} onChange={setCompletionPhotos} label="Upload After-Cleaning Photos" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: info + actions */}
        <div className="space-y-6">
          {/* People info */}
          <div className="card p-5">
            <h3 className="font-semibold text-slate-900 mb-3">Details</h3>
            <dl className="space-y-3 text-sm">
              <div>
                <dt className="text-slate-400 text-xs">Reported By</dt>
                <dd className="text-slate-700 font-medium flex items-center gap-1.5 mt-0.5">
                  <User className="h-3.5 w-3.5 text-slate-400" />
                  {complaint.citizen?.full_name || 'Unknown'}
                  {complaint.citizen?.zone && <span className="text-xs text-slate-400">• {complaint.citizen.zone}</span>}
                </dd>
              </div>
              {complaint.assigned_collector && (
                <div>
                  <dt className="text-slate-400 text-xs">Assigned Collector</dt>
                  <dd className="text-slate-700 font-medium flex items-center gap-1.5 mt-0.5">
                    <User className="h-3.5 w-3.5 text-slate-400" />
                    {complaint.assigned_collector.full_name}
                    {complaint.assigned_collector.zone && <span className="text-xs text-slate-400">• {complaint.assigned_collector.zone}</span>}
                  </dd>
                </div>
              )}
              <div>
                <dt className="text-slate-400 text-xs">Reported On</dt>
                <dd className="text-slate-700 font-medium mt-0.5">{formatDateTime(complaint.created_at)}</dd>
              </div>
              {complaint.started_at && (
                <div>
                  <dt className="text-slate-400 text-xs">Started</dt>
                  <dd className="text-slate-700 font-medium mt-0.5">{formatDateTime(complaint.started_at)}</dd>
                </div>
              )}
              {complaint.completed_at && (
                <div>
                  <dt className="text-slate-400 text-xs">Completed</dt>
                  <dd className="text-slate-700 font-medium mt-0.5">{formatDateTime(complaint.completed_at)}</dd>
                </div>
              )}
              {complaint.admin_notes && (
                <div>
                  <dt className="text-slate-400 text-xs">Admin Notes</dt>
                  <dd className="text-slate-700 mt-0.5">{complaint.admin_notes}</dd>
                </div>
              )}
            </dl>
          </div>

          {/* Admin actions */}
          {isAdmin && (complaint.status === 'Pending' || complaint.status === 'Assigned') && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-3">Assign Collector</h3>
              <div className="space-y-3">
                <select
                  className="input"
                  value={selectedCollector}
                  onChange={(e) => setSelectedCollector(e.target.value)}
                >
                  <option value="">Select a collector...</option>
                  {collectors.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.full_name}{c.zone ? ` — ${c.zone}` : ''}
                    </option>
                  ))}
                </select>
                <textarea
                  className="input resize-none text-sm"
                  rows={2}
                  placeholder="Admin notes (optional)"
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                />
                <button
                  onClick={handleAssign}
                  disabled={!selectedCollector || actionLoading}
                  className="btn-primary w-full text-sm"
                >
                  {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <>Assign Collector</>}
                </button>
                {complaint.status === 'Pending' && (
                  <button
                    onClick={handleReject}
                    disabled={actionLoading}
                    className="btn-ghost text-red-600 hover:bg-red-50 w-full text-sm"
                  >
                    <XCircle className="h-4 w-4" /> Reject Complaint
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Collector actions */}
          {canStartProgress && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-2">Start Collection</h3>
              <p className="text-sm text-slate-500 mb-3">
                Mark this task as in progress when you begin collecting.
              </p>
              <button onClick={handleStartProgress} disabled={actionLoading} className="btn-primary w-full">
                {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><PlayCircle className="h-4 w-4" /> Start Collection</>}
              </button>
            </div>
          )}

          {canComplete && (
            <div className="card p-5">
              <h3 className="font-semibold text-slate-900 mb-2">Complete Collection</h3>
              <p className="text-sm text-slate-500 mb-3">
                Upload after-cleaning photos and mark this task as completed.
              </p>
              <button onClick={handleComplete} disabled={actionLoading || completionPhotos.length === 0} className="btn-primary w-full">
                {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle2 className="h-4 w-4" /> Mark as Completed</>}
              </button>
              {completionPhotos.length === 0 && (
                <p className="text-xs text-amber-600 mt-2 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" /> Upload at least one after-cleaning photo.
                </p>
              )}
            </div>
          )}

          {/* Timeline */}
          <div className="card p-5">
            <h3 className="font-semibold text-slate-900 mb-3">Timeline</h3>
            <div className="space-y-3">
              {[
                { label: 'Reported', date: complaint.created_at, done: true },
                { label: 'Assigned', date: complaint.status !== 'Pending' ? complaint.updated_at : null, done: complaint.status !== 'Pending' && complaint.status !== 'Rejected' },
                { label: 'In Progress', date: complaint.started_at, done: complaint.status === 'In Progress' || complaint.status === 'Completed' },
                { label: 'Completed', date: complaint.completed_at, done: complaint.status === 'Completed' },
              ].map((step, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className={classNames(
                    'flex h-7 w-7 items-center justify-center rounded-full shrink-0',
                    step.done ? 'bg-primary-100 text-primary-600' : 'bg-slate-100 text-slate-300'
                  )}>
                    {step.done ? <CheckCircle2 className="h-4 w-4" /> : <span className="text-xs font-bold">{i + 1}</span>}
                  </div>
                  <div className="min-w-0">
                    <p className={classNames('text-sm font-medium', step.done ? 'text-slate-900' : 'text-slate-400')}>{step.label}</p>
                    {step.date && <p className="text-xs text-slate-400">{formatDateTime(step.date)}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Photo lightbox */}
      {activePhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setActivePhoto(null)}
        >
          <img src={activePhoto} alt="Full size" className="max-h-[90vh] max-w-full rounded-xl" />
          <button className="absolute top-4 right-4 p-2 rounded-lg bg-white/10 text-white hover:bg-white/20">
            <XCircle className="h-6 w-6" />
          </button>
        </div>
      )}
    </div>
  );
}
