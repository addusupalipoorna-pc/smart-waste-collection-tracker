import { STATUS_META } from '@/lib/constants';
import type { ComplaintStatus, Urgency } from '@/types';
import { URGENCY_LEVELS } from '@/lib/constants';

export function StatusBadge({ status }: { status: ComplaintStatus }) {
  const meta = STATUS_META[status];
  return (
    <span
      className="badge"
      style={{ color: meta.color, backgroundColor: meta.bg }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.color }} />
      {meta.label}
    </span>
  );
}

export function UrgencyBadge({ urgency }: { urgency: Urgency }) {
  const meta = URGENCY_LEVELS.find((u) => u.value === urgency);
  if (!meta) return null;
  return (
    <span
      className="badge"
      style={{ color: meta.color, backgroundColor: `${meta.color}1a` }}
    >
      {meta.label}
    </span>
  );
}
