import { Link, Outlet, useLocation, useNavigate, NavigateFunction } from 'react-router-dom';
import { useState, type ReactNode } from 'react';
import {
  LayoutDashboard, FileText, Map, BarChart3, Users, LogOut, Menu, X,
  Leaf, Bell, User, ClipboardList, PlusCircle, History,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { NotificationBell } from '@/components/NotificationBell';
import { ROLE_META } from '@/lib/constants';
import { classNames, initialFromName } from '@/lib/utils';
import type { UserRole } from '@/types';

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
}

const navByRole: Record<UserRole, NavItem[]> = {
  citizen: [
    { to: '/citizen', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/citizen/report', label: 'Report Waste', icon: PlusCircle },
    { to: '/citizen/history', label: 'My Complaints', icon: History },
  ],
  collector: [
    { to: '/collector', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/collector/assigned', label: 'Assigned Tasks', icon: ClipboardList },
    { to: '/collector/map', label: 'Route Map', icon: Map },
  ],
  admin: [
    { to: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/admin/complaints', label: 'All Complaints', icon: FileText },
    { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/admin/users', label: 'Manage Users', icon: Users },
    { to: '/admin/map', label: 'Live Map', icon: Map },
  ],
};

export function DashboardLayout() {
  const { profile, signOut } = useAuth();
  const location = useLocation();
  const navigate: NavigateFunction = useNavigate();
  const [mobileSidebar, setMobileSidebar] = useState(false);

  if (!profile) {
    navigate('/login');
    return null;
  }

  const navItems = navByRole[profile.role] || [];
  const roleMeta = ROLE_META[profile.role];

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const Sidebar = (
    <div className="flex flex-col h-full">
      <Link to="/" className="flex items-center gap-2 px-6 py-5 border-b border-slate-100">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-emerald-600 shadow-lg shadow-primary-500/30">
          <Leaf className="h-5 w-5 text-white" />
        </div>
        <div>
          <span className="font-display text-base font-bold text-slate-900 block leading-tight">SmartWaste</span>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider">Tracker</span>
        </div>
      </Link>

      <div className="px-4 py-3 border-b border-slate-100">
        <div className="flex items-center gap-3 px-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-100 text-primary-700 font-semibold">
            {initialFromName(profile.full_name)}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-900 truncate">{profile.full_name}</p>
            <span className="text-xs" style={{ color: roleMeta.color }}>{roleMeta.label}</span>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const active = location.pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setMobileSidebar(false)}
              className={classNames(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                active
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
            >
              <item.icon className={classNames('h-5 w-5', active ? 'text-primary-600' : 'text-slate-400')} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-3 py-4 border-t border-slate-100 space-y-1">
        <Link
          to="/profile"
          onClick={() => setMobileSidebar(false)}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50"
        >
          <User className="h-5 w-5 text-slate-400" /> My Profile
        </Link>
        <button
          onClick={handleSignOut}
          className="flex w-full items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50"
        >
          <LogOut className="h-5 w-5" /> Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-64 flex-col bg-white border-r border-slate-200 fixed inset-y-0 left-0 z-30">
        {Sidebar}
      </aside>

      {/* Mobile sidebar */}
      {mobileSidebar && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/30" onClick={() => setMobileSidebar(false)} />
          <aside className="relative w-64 bg-white flex flex-col animate-fade-in">
            {Sidebar}
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-xl border-b border-slate-200/80 h-16 flex items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
              onClick={() => setMobileSidebar(!mobileSidebar)}
            >
              {mobileSidebar ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <h1 className="font-display text-base sm:text-lg font-bold text-slate-900 capitalize">
              {profile.role} Portal
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell userId={profile.id} />
            <Link
              to="/profile"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-100 text-primary-700 text-sm font-semibold hover:bg-primary-200 transition-colors"
            >
              {initialFromName(profile.full_name)}
            </Link>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
      <div>
        <h2 className="font-display text-2xl font-bold text-slate-900">{title}</h2>
        {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
