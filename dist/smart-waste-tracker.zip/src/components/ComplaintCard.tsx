import { Link } from 'react-router-dom';
import { MapPin, Clock, Trash2, ArrowRight } from 'lucide-react';
import type { Complaint } from '@/types';
import { StatusBadge, UrgencyBadge } from '@/components/Badges';
import { timeAgo, classNames } from '@/lib/utils';
import { WASTE_TYPES } from '@/lib/constants';

interface ComplaintCardProps {
  complaint: Complaint;
  to: string;
  showCitizen?: boolean;
  showCollector?: boolean;
  onDelete?: (id: string) => void;
  compact?: boolean;
}

export function ComplaintCard({ complaint, to, showCitizen, showCollector, onDelete, compact }: ComplaintCardProps) {
  const wasteType = WASTE_TYPES.find((w) => w.value === complaint.waste_type);

  return (
    <Link
      to={to}
      className="card card-hover p-4 block group"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <div
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-white text-xs font-bold"
            style={{ backgroundColor: wasteType?.color || '#64748b' }}
          >
            {complaint.waste_type.slice(0, 2).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-slate-900 text-sm truncate">{complaint.complaint_code}</p>
            <p className="text-xs text-slate-500">{complaint.waste_type} Waste</p>
          </div>
        </div>
        <StatusBadge status={complaint.status} />
      </div>

      {!compact && (
        <p className="text-sm text-slate-600 line-clamp-2 mb-3">{complaint.description}</p>
      )}

      <div className="flex items-center flex-wrap gap-2 mb-3">
        <UrgencyBadge urgency={complaint.urgency} />
        {showCitizen && complaint.citizen && (
          <span className="badge bg-slate-100 text-slate-600">
            By {complaint.citizen.full_name}
          </span>
        )}
        {showCollector && complaint.assigned_collector && (
          <span className="badge bg-cyan-50 text-cyan-700">
            {complaint.assigned_collector.full_name}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" /> {timeAgo(complaint.created_at)}
          </span>
          {complaint.address && (
            <span className="flex items-center gap-1 truncate max-w-[160px]">
              <MapPin className="h-3 w-3" /> {complaint.address}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {onDelete && (
            <button
              onClick={(e) => {
                e.preventDefault();
                onDelete(complaint.id);
              }}
              className="p-1 text-slate-300 hover:text-red-500 transition-colors"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
          <ArrowRight className={classNames('h-4 w-4 text-slate-300 group-hover:text-primary-500 transition-colors')} />
        </div>
      </div>
    </Link>
  );
}
