import { Link } from 'react-router-dom';
import { Leaf, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="container-app px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-emerald-600">
                <Leaf className="h-5 w-5 text-white" />
              </div>
              <span className="font-display text-lg font-bold text-white">SmartWaste Tracker</span>
            </div>
            <p className="text-sm text-slate-400 max-w-md leading-relaxed">
              An intelligent waste management platform empowering villages to maintain
              cleanliness through community reporting, efficient collection, and real-time monitoring.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" className="hover:text-primary-400 transition-colors">About</Link></li>
              <li><Link to="/services" className="hover:text-primary-400 transition-colors">Services</Link></li>
              <li><Link to="/contact" className="hover:text-primary-400 transition-colors">Contact</Link></li>
              <li><Link to="/login" className="hover:text-primary-400 transition-colors">Sign In</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Contact</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2"><Mail className="h-4 w-4" /> support@smartwaste.gov</li>
              <li className="flex items-center gap-2"><Phone className="h-4 w-4" /> 1800-XXX-XXXX</li>
              <li className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Gram Panchayat Office</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p className="text-xs text-slate-500">© {new Date().getFullYear()} Smart Waste Collection Tracker. All rights reserved.</p>
          <p className="text-xs text-slate-500">Built for cleaner, healthier villages.</p>
        </div>
      </div>
    </footer>
  );
}
