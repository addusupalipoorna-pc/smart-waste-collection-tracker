import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useEffect } from 'react';
import L from 'leaflet';
import type { Complaint } from '@/types';
import { STATUS_META } from '@/lib/constants';
import { DEFAULT_MAP_CENTER, DEFAULT_MAP_ZOOM } from '@/lib/constants';

// Fix default marker icon for Leaflet in bundlers
const defaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});
L.Marker.prototype.options.icon = defaultIcon;

function createColoredIcon(color: string) {
  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="
      width: 24px; height: 24px; border-radius: 50% 50% 50% 0;
      background: ${color}; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);
      transform: rotate(-45deg);"></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -20],
  });
}

function MapResizer() {
  const map = useMap();
  useEffect(() => {
    setTimeout(() => map.invalidateSize(), 100);
  }, [map]);
  return null;
}

interface MapViewProps {
  complaints?: Complaint[];
  center?: [number, number];
  zoom?: number;
  height?: string;
  showPopups?: boolean;
  singleMarker?: { lat: number; lng: number; label?: string };
  onMarkerClick?: (id: string) => void;
}

export function MapView({
  complaints = [],
  center = DEFAULT_MAP_CENTER,
  zoom = DEFAULT_MAP_ZOOM,
  height = '400px',
  showPopups = true,
  singleMarker,
  onMarkerClick,
}: MapViewProps) {
  return (
    <div style={{ height }} className="rounded-2xl overflow-hidden border border-slate-200 z-0">
      <MapContainer center={center} zoom={zoom} className="h-full w-full" scrollWheelZoom>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapResizer />

        {singleMarker && (
          <Marker position={[singleMarker.lat, singleMarker.lng]} icon={createColoredIcon('#16a34a')}>
            {singleMarker.label && (
              <Popup>
                <div className="text-sm">
                  <p className="font-semibold">{singleMarker.label}</p>
                </div>
              </Popup>
            )}
          </Marker>
        )}

        {complaints.map((c) => {
          if (c.latitude == null || c.longitude == null) return null;
          const meta = STATUS_META[c.status];
          return (
            <Marker
              key={c.id}
              position={[c.latitude, c.longitude]}
              icon={createColoredIcon(meta.color)}
              eventHandlers={onMarkerClick ? { click: () => onMarkerClick(c.id) } : undefined}
            >
              {showPopups && (
                <Popup>
                  <div className="text-sm min-w-[180px]">
                    <p className="font-semibold text-slate-900">{c.complaint_code}</p>
                    <p className="text-slate-600">{c.waste_type} Waste</p>
                    <p className="text-xs text-slate-500 mt-1">{c.description.slice(0, 80)}</p>
                    <p className="mt-1" style={{ color: meta.color, fontWeight: 600 }}>{meta.label}</p>
                  </div>
                </Popup>
              )}
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}
