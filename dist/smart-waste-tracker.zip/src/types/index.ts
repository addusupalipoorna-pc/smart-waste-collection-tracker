export type UserRole = 'citizen' | 'collector' | 'admin';

export type WasteType =
  | 'Plastic'
  | 'Organic'
  | 'Electronic'
  | 'Hazardous'
  | 'Medical'
  | 'Construction'
  | 'Mixed';

export type Urgency = 'Low' | 'Medium' | 'High' | 'Critical';

export type ComplaintStatus =
  | 'Pending'
  | 'Assigned'
  | 'In Progress'
  | 'Completed'
  | 'Rejected';

export type NotificationType =
  | 'info'
  | 'assignment'
  | 'status'
  | 'completion'
  | 'system';

export interface Profile {
  id: string;
  full_name: string;
  role: UserRole;
  phone: string | null;
  zone: string | null;
  avatar_url: string | null;
  created_at: string;
}

export interface Complaint {
  id: string;
  complaint_code: string;
  citizen_id: string;
  waste_type: WasteType;
  description: string;
  urgency: Urgency;
  status: ComplaintStatus;
  latitude: number | null;
  longitude: number | null;
  address: string | null;
  photos: string[];
  assigned_collector_id: string | null;
  collection_photos: string[];
  completion_photos: string[];
  admin_notes: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  // Joined relations (optional — present when selected)
  citizen?: Profile;
  assigned_collector?: Profile | null;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  related_complaint_id: string | null;
  read: boolean;
  created_at: string;
}

export interface ComplaintWithRelations extends Complaint {
  citizen?: Profile;
  assigned_collector?: Profile | null;
}
